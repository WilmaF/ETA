class User:
    def __init__(self, name, job):
        self.name = name
        self.job = job